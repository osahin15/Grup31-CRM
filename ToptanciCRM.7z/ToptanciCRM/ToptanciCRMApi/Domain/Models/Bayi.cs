﻿using System;
using System.Collections.Generic;

namespace ToptanciCRMApi.Domain
{
    public partial class Bayi
    {
        public int BayiId { get; set; }
        public string BayiAd { get; set; }
        public string BayiMail { get; set; }
        public string BayiAdres { get; set; }


    }
}
