﻿using System;
using System.Collections.Generic;

namespace ToptanciCRMApi.Domain
{
    public partial class Toptanci
    {
        public int ToptanciId { get; set; }
        public string ToptanciAd { get; set; }
    }
}
