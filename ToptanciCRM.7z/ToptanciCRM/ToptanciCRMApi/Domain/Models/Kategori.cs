﻿using System;
using System.Collections.Generic;

namespace ToptanciCRMApi.Domain
{
    public partial class Kategori
    {
        public int KategoriId { get; set; }
        public string KategoriAd { get; set; }
    }
}
