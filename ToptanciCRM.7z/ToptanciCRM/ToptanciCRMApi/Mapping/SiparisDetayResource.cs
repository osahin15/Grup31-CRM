﻿namespace ToptanciCRMApi.Mapping
{
    internal class SiparisDetayResource
    {
    }
}