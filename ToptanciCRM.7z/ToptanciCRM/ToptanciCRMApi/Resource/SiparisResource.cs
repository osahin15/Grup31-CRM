﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToptanciCRMApi.Resource
{
    public class SiparisResource
    {
        public int BayiId { get; set; }
        public int ToptanciId { get; set; }
    }
}
