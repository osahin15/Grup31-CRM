﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToptanciCRMApi.Resource
{
    public class UrunResource
    {
        public string UrunAd { get; set; }
        public int? UrunFiyat { get; set; }
        public int? KategoriId { get; set; }
    }
}
