﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToptanciCRMApi.Resource
{
    public class TokenResource
    {
        public string RefreshToken { get; set; }
    }
}
