﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToptanciCRMApi.Resource
{
    public class SiparisDetayResource
    {
        public int UrunId { get; set; }
        public int Adet { get; set; }
        public int SiparisId { get; set; }
    }
}
